import JSZip from "jszip";
import type {
  TemplateFileExt,
  TemplatePreviewBlock,
  TemplatePreviewGroup,
  TemplatePreviewResolvedSource,
  TemplatePreviewSource,
} from "@/lib/schemas";
import { extractPlaceholders } from "@/lib/placeholders";

const DOCX_PARAGRAPH_REGEX = /<w:p\b[\s\S]*?<\/w:p>/g;
const DOCX_TEXT_RUN_REGEX = /<w:t\b[^>]*>([\s\S]*?)<\/w:t>/g;
const DOCX_TEXT_NODE_REGEX = /<w:t\b[^>]*>[\s\S]*?<\/w:t>/g;

const PPT_PARAGRAPH_REGEX = /<a:p\b[\s\S]*?<\/a:p>/g;
const PPT_TEXT_RUN_REGEX = /<a:t\b[^>]*>([\s\S]*?)<\/a:t>/g;
const PPT_TEXT_NODE_REGEX = /<a:t\b[^>]*>[\s\S]*?<\/a:t>/g;

const XML_ENTITY_MAP: Record<string, string> = {
  amp: "&",
  lt: "<",
  gt: ">",
  quot: '"',
  apos: "'",
};

function decodeXml(value: string): string {
  return value.replace(/&(amp|lt|gt|quot|apos);/g, (_, key: string) => {
    return XML_ENTITY_MAP[key] ?? _;
  });
}

function escapeXml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function getDocxXmlPaths(zip: JSZip): string[] {
  return Object.values(zip.files)
    .filter((entry) => !entry.dir)
    .map((entry) => entry.name)
    .filter((name) => name.startsWith("word/") && name.endsWith(".xml"))
    .sort((a, b) => a.localeCompare(b));
}

function parseSlideNumber(path: string): number {
  const match = path.match(/slide(\d+)\.xml$/i);
  return match ? Number(match[1]) : Number.MAX_SAFE_INTEGER;
}

function getPptSlidePaths(zip: JSZip): string[] {
  return Object.values(zip.files)
    .filter((entry) => !entry.dir)
    .map((entry) => entry.name)
    .filter((name) => name.startsWith("ppt/slides/") && /slide\d+\.xml$/i.test(name))
    .sort((a, b) => parseSlideNumber(a) - parseSlideNumber(b));
}

function extractJoinedRuns(containerXml: string, runRegex: RegExp): string {
  const textRuns = Array.from(containerXml.matchAll(runRegex));
  return textRuns.map((match) => decodeXml(match[1])).join("");
}

export function buildBlockId(xmlPath: string, nodeIndex: number): string {
  return `${xmlPath}#${nodeIndex}`;
}

function rewriteTextNodes(
  containerXml: string,
  textNodeRegex: RegExp,
  closingTag: "w:t" | "a:t",
  newText: string
): string {
  let seen = 0;
  const escaped = escapeXml(newText);
  const contentRegex = new RegExp(`>([\\s\\S]*?)<\\/${closingTag}>`);

  return containerXml.replace(textNodeRegex, (textNodeXml) => {
    const replacement = seen === 0 ? escaped : "";
    seen += 1;
    return textNodeXml.replace(contentRegex, `>${replacement}</${closingTag}>`);
  });
}

function createBlock(args: {
  fileId: string;
  groupId: string;
  groupLabel: string;
  xmlPath: string;
  nodeIndex: number;
  text: string;
  order: number;
}): TemplatePreviewBlock {
  return {
    id: buildBlockId(args.xmlPath, args.nodeIndex),
    fileId: args.fileId,
    groupId: args.groupId,
    groupLabel: args.groupLabel,
    xmlPath: args.xmlPath,
    nodeIndex: args.nodeIndex,
    text: args.text,
    placeholders: extractPlaceholders(args.text),
    order: args.order,
  };
}

export async function extractEditableBlocksFromOoxml(
  buffer: Buffer,
  ext: TemplateFileExt,
  fileId: string
): Promise<{ groups: TemplatePreviewGroup[]; blocks: TemplatePreviewBlock[] }> {
  const zip = await JSZip.loadAsync(buffer);
  const groups: TemplatePreviewGroup[] = [];
  const blocks: TemplatePreviewBlock[] = [];
  let order = 0;

  if (ext === "docx") {
    const xmlPaths = getDocxXmlPaths(zip);

    for (let groupOrder = 0; groupOrder < xmlPaths.length; groupOrder += 1) {
      const xmlPath = xmlPaths[groupOrder];
      const xmlFile = zip.file(xmlPath);
      if (!xmlFile) continue;

      const groupId = `docx:${xmlPath}`;
      const groupLabel = `Dokument ${xmlPath.replace(/^word\//, "")}`;
      groups.push({ id: groupId, label: groupLabel, order: groupOrder });

      const xml = await xmlFile.async("string");
      const paragraphs = Array.from(xml.matchAll(DOCX_PARAGRAPH_REGEX));

      for (let nodeIndex = 0; nodeIndex < paragraphs.length; nodeIndex += 1) {
        const paragraphXml = paragraphs[nodeIndex][0];
        const text = extractJoinedRuns(paragraphXml, DOCX_TEXT_RUN_REGEX);
        if (text.trim() === "") continue;

        blocks.push(
          createBlock({
            fileId,
            groupId,
            groupLabel,
            xmlPath,
            nodeIndex,
            text,
            order: order++,
          })
        );
      }
    }

    return { groups, blocks };
  }

  const slidePaths = getPptSlidePaths(zip);

  for (let groupOrder = 0; groupOrder < slidePaths.length; groupOrder += 1) {
    const xmlPath = slidePaths[groupOrder];
    const xmlFile = zip.file(xmlPath);
    if (!xmlFile) continue;

    const slideNumber = parseSlideNumber(xmlPath);
    const groupId = `slide:${slideNumber}`;
    const groupLabel = `Folie ${slideNumber}`;
    groups.push({ id: groupId, label: groupLabel, order: groupOrder });

    const xml = await xmlFile.async("string");
    const paragraphs = Array.from(xml.matchAll(PPT_PARAGRAPH_REGEX));

    for (let nodeIndex = 0; nodeIndex < paragraphs.length; nodeIndex += 1) {
      const paragraphXml = paragraphs[nodeIndex][0];
      const text = extractJoinedRuns(paragraphXml, PPT_TEXT_RUN_REGEX);
      if (text.trim() === "") continue;

      blocks.push(
        createBlock({
          fileId,
          groupId,
          groupLabel,
          xmlPath,
          nodeIndex,
          text,
          order: order++,
        })
      );
    }
  }

  return { groups, blocks };
}

export async function applyBlockEditsToOoxml(
  buffer: Buffer,
  ext: TemplateFileExt,
  editsByBlockId: Record<string, string>
): Promise<Buffer> {
  const zip = await JSZip.loadAsync(buffer);

  if (ext === "docx") {
    const xmlPaths = getDocxXmlPaths(zip);

    for (const xmlPath of xmlPaths) {
      const xmlFile = zip.file(xmlPath);
      if (!xmlFile) continue;

      let nodeIndex = 0;
      const xml = await xmlFile.async("string");
      const updated = xml.replace(DOCX_PARAGRAPH_REGEX, (paragraphXml) => {
        const blockId = buildBlockId(xmlPath, nodeIndex);
        nodeIndex += 1;

        const nextText = editsByBlockId[blockId];
        if (nextText === undefined) {
          return paragraphXml;
        }

        return rewriteTextNodes(paragraphXml, DOCX_TEXT_NODE_REGEX, "w:t", nextText);
      });

      zip.file(xmlPath, updated);
    }

    return zip.generateAsync({ type: "nodebuffer" });
  }

  const slidePaths = getPptSlidePaths(zip);

  for (const xmlPath of slidePaths) {
    const xmlFile = zip.file(xmlPath);
    if (!xmlFile) continue;

    let nodeIndex = 0;
    const xml = await xmlFile.async("string");
    const updated = xml.replace(PPT_PARAGRAPH_REGEX, (paragraphXml) => {
      const blockId = buildBlockId(xmlPath, nodeIndex);
      nodeIndex += 1;

      const nextText = editsByBlockId[blockId];
      if (nextText === undefined) {
        return paragraphXml;
      }

      return rewriteTextNodes(paragraphXml, PPT_TEXT_NODE_REGEX, "a:t", nextText);
    });

    zip.file(xmlPath, updated);
  }

  return zip.generateAsync({ type: "nodebuffer" });
}

export function resolveBlockPlaceholders(
  blocks: Pick<TemplatePreviewBlock, "placeholders">[],
  mergedMap: Record<string, string>
): string[] {
  const unresolved = new Set<string>();

  for (const block of blocks) {
    for (const token of block.placeholders) {
      const value = mergedMap[token];
      if (value === undefined || value.trim() === "") {
        unresolved.add(token);
      }
    }
  }

  return Array.from(unresolved).sort();
}

export function resolvePreviewSource(
  requested: TemplatePreviewSource,
  hasGenerated: boolean
): TemplatePreviewResolvedSource {
  if (requested === "generated") {
    return hasGenerated ? "generated" : "original";
  }

  if (requested === "original") {
    return "original";
  }

  return hasGenerated ? "generated" : "original";
}
