import JSZip from "jszip";
import type { TemplateFileExt } from "@/lib/schemas";

const PLACEHOLDER_REGEX = /\{\{([A-Z0-9_]+)\}\}/g;

function escapeXml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function getXmlEntryPaths(zip: JSZip, ext: TemplateFileExt): string[] {
  const root = ext === "docx" ? "word/" : "ppt/";

  return Object.values(zip.files)
    .filter((entry) => !entry.dir)
    .map((entry) => entry.name)
    .filter((name) => name.startsWith(root) && name.endsWith(".xml"));
}

function extractPlaceholdersFromText(text: string): string[] {
  const found = new Set<string>();
  const regex = new RegExp(PLACEHOLDER_REGEX.source, "g");
  let match: RegExpExecArray | null;

  while ((match = regex.exec(text)) !== null) {
    found.add(match[1]);
  }

  return Array.from(found);
}

export async function extractPlaceholdersFromOoxml(
  buffer: Buffer,
  ext: TemplateFileExt
): Promise<string[]> {
  const zip = await JSZip.loadAsync(buffer);
  const xmlPaths = getXmlEntryPaths(zip, ext);
  const placeholders = new Set<string>();

  for (const xmlPath of xmlPaths) {
    const xmlFile = zip.file(xmlPath);
    if (!xmlFile) continue;

    const xml = await xmlFile.async("string");
    for (const token of extractPlaceholdersFromText(xml)) {
      placeholders.add(token);
    }
  }

  return Array.from(placeholders).sort();
}

export async function applyPlaceholderMapToOoxml(
  buffer: Buffer,
  ext: TemplateFileExt,
  map: Record<string, string>
): Promise<{ output: Buffer; unresolved: string[] }> {
  const zip = await JSZip.loadAsync(buffer);
  const xmlPaths = getXmlEntryPaths(zip, ext);
  const unresolved = new Set<string>();

  for (const xmlPath of xmlPaths) {
    const xmlFile = zip.file(xmlPath);
    if (!xmlFile) continue;

    const xml = await xmlFile.async("string");

    const replaced = xml.replace(
      new RegExp(PLACEHOLDER_REGEX.source, "g"),
      (match, key: string) => {
        const value = map[key];
        if (value === undefined || value === "") {
          unresolved.add(key);
          return match;
        }

        return escapeXml(value);
      }
    );

    zip.file(xmlPath, replaced);
  }

  const output = await zip.generateAsync({ type: "nodebuffer" });
  return {
    output,
    unresolved: Array.from(unresolved).sort(),
  };
}
